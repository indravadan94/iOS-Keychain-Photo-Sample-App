//
//  FirstViewController.swift
//  iOS Keychain Photo Sample App
//
//  Created by INDRAVADAN SHRIMALI on 2019-08-18.
//  Copyright © 2019 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import Security



class FirstViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    //Mark: - Declarations
    var arrnewImage = [UIImage]()
    var imagePicker = UIImagePickerController()
     var imgArray = [UIImage]()
    
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // MARK: - Setting Delegates
        imagePicker.delegate = (self as UIImagePickerControllerDelegate & UINavigationControllerDelegate)
        tblView.delegate = self
        tblView.dataSource = self
        
//        tblView.reloadData()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
      
            self.getDataFromKeychain()
            tblView.reloadData()
        
        
        
        
    }
    
    // MARK: - Method to save data in keychain
    func saveDataInKeychain(){
    
        var imgStringArray = [String]()
        
        for img in arrnewImage{
        
        
        let imgStr =  img.jpegData(compressionQuality: 0.1)?.base64EncodedString()
        
        imgStringArray.append(imgStr!)
        
        }
        
        
        let stringRepresentation = imgStringArray.joined(separator: ",")
        
       
            KeychainService.savePassword(token: stringRepresentation as NSString)
        
        
        
        
        
    }

    // MARK: - Method to fetch data from keychain
    func getDataFromKeychain(){

        let pass = KeychainService.loadPassword()

        if (pass == nil) && (imgArray .isEmpty) {
            
           print("No data in Keychain")

        }
        else
        {
            let strImages = pass!.components(separatedBy: ",")
            imgArray = []
            for imgString in strImages{
                if(imgString .isEmpty){
                    
                    print("No Data")
                }
                else{
                     imgArray.append((imgString.toImage())!)
                }
            }
            
            print("Keychain Data \(imgArray)")
        }
        
       
    }


    
    // MARK: - Table View Delegate Methods
    @IBOutlet weak var tblView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : CustomCellVCTableViewCell = tblView.dequeueReusableCell(withIdentifier: "cell") as! CustomCellVCTableViewCell
        
        
        cell.imgView.image = imgArray[indexPath.row]
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        
        tblView.rowHeight = UITableView.automaticDimension
       
         return 350
    }
    
   
    //MARK: - Adding Images to Table View
    
    @IBOutlet weak var btnAddImage: UIButton!
    @IBAction func btnAddImageTapped(_ sender: Any) {
        
         let alert = UIAlertController(title: "Title", message: "Please Select an Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Choose Photo From Library", style: .default, handler: { (_) in
            
            self.imagePicker.allowsEditing = false
            self.imagePicker.sourceType = .photoLibrary
            self.imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
            self.present(self.imagePicker, animated: true, completion: nil)
            
        }))
        
        alert.addAction(UIAlertAction(title: "Take Photo From Camera", style: .default, handler: { (_) in
            
            if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
            {
                self.imagePicker.sourceType = UIImagePickerController.SourceType.camera
                self.imagePicker.allowsEditing = true
                self.present(self.imagePicker, animated: true, completion: nil)
            }
            else
            {
                let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            
        }))
        
        
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
        
    }
    
    // MARK: - UIImagePickerControllerDelegate Methods
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
           // imageData = UIImageJPEGRepresentation((info[UIImagePickerControllerOriginalImage] as? UIImage)!, 0.5)
            
            let imageView = UIImageView()
            imageView.frame = CGRect(x: 0, y: 0, width: 100, height: 200)
            imageView.contentMode = .scaleAspectFit
            imageView.image = pickedImage
            print("Image \(String(describing: imageView.image))")

            arrnewImage.append(imageView.image!)
          
           
                self.saveDataInKeychain()
                
                self.getDataFromKeychain()

            
            
            
        }
       imagePicker.dismiss(animated: true, completion: nil)
      
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        print(arrnewImage)
        imagePicker.dismiss(animated: true, completion: nil)
    }

}

extension String {
    func toImage() -> UIImage? {
        if let data = Data(base64Encoded: self, options: .ignoreUnknownCharacters){
            return UIImage(data: data)
        }
        return nil
    }
}

extension UIImage {
    
    /// EZSE: Returns base64 string
    public var base64: String {
        return self.jpegData(compressionQuality: 1.0)!.base64EncodedString()
    }
}


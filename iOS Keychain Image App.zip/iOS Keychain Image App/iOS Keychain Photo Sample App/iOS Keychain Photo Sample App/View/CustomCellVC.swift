//
//  CustomCellVCTableViewCell.swift
//  iOS Keychain Photo Sample App
//
//  Created by INDRAVADAN SHRIMALI on 2019-08-18.
//  Copyright © 2019 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class CustomCellVCTableViewCell: UITableViewCell {

    @IBOutlet weak var imgView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
  

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    
}

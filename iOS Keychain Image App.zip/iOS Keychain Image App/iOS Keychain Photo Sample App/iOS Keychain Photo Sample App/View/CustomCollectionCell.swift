//
//  CustomCollectionCell.swift
//  iOS Keychain Photo Sample App
//
//  Created by INDRAVADAN SHRIMALI on 2019-08-19.
//  Copyright © 2019 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class CustomCollectionCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imgView: UIImageView!
}

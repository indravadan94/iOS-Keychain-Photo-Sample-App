//
//  SecondViewController.swift
//  iOS Keychain Photo Sample App
//
//  Created by INDRAVADAN SHRIMALI on 2019-08-18.
//  Copyright © 2019 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UIGestureRecognizerDelegate,UIActionSheetDelegate,UICollectionViewDelegateFlowLayout {
    
    
    var rowWidth : CGFloat!
    var imgArray = [UIImage]()
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var btnSegment: UISegmentedControl!
    
    
   

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        
        rowWidth = collectionView.frame.size.width
        
        
      
         
            self.getDataFromKeychain()
        
        
        
        
        
        
       
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    
    
    // MARK: - Method to fetch data from keychain
    func getDataFromKeychain(){
        
        let pass = KeychainService.loadPassword()
        
        if (pass == nil) && (imgArray .isEmpty) {
            
            print("No data in Keychain")
            
        }
        else
        {
            let strImages = pass!.components(separatedBy: ",")
            imgArray = []
            for imgString in strImages{
                if(imgString .isEmpty){
                    
                    print("No Data")
                }
                else{
                    imgArray.append((imgString.toImage())!)
                }
            }
            
            print("Keychain Data \(imgArray)")
        }
        collectionView.reloadData()
        
    }
    
    func saveDataInKeychain(){
        
        var imgStringArray = [String]()
        
        for img in imgArray{
            
            
            let imgStr =  img.jpegData(compressionQuality: 0.1)?.base64EncodedString()
            
            imgStringArray.append(imgStr!)
            
        }
        
        
        let stringRepresentation = imgStringArray.joined(separator: ",")
        
       
             KeychainService.savePassword(token: stringRepresentation as NSString)
        
       
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
            self.getDataFromKeychain()
        
        
        collectionView.reloadData()
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
       
        //collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imgArray.count
    }
    
    
    private func collectionView(collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSize(width: rowWidth, height: 300)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1.0
    }

    func collectionView(_ collectionView: UICollectionView, layout
        collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1.0
    }

    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        
       let cell2 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! CustomCollectionCell
        
        
        cell2.imgView.image = imgArray[indexPath.row]
        
        
        return cell2
        
    }
    
    @objc
    func handleLongPress(longPressGR: UILongPressGestureRecognizer) {
        if longPressGR.state != .ended {
            return
        }
        
        let point = longPressGR.location(in: self.collectionView)
        let indexPath = self.collectionView.indexPathForItem(at: point)
        
        if let indexPath = indexPath {
            _ = self.collectionView.cellForItem(at: indexPath)
        
            let alert = UIAlertController(title: "Title", message: "Please Select an Option", preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Delete", style: .default, handler: { (_) in
               
                print("Indexpath \(indexPath.row)")
                self.imgArray.remove(at: indexPath.row)
                
                self.saveDataInKeychain()
                
                self.getDataFromKeychain()
                
                self.collectionView.reloadData()
               
                
            }))
            
           
            
            self.present(alert, animated: true, completion: {
                print("completion block")
            })
            
        } else {
            print("Could not find index path")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let longPressGR = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(longPressGR:)))
        longPressGR.minimumPressDuration = 0.5
        longPressGR.delaysTouchesBegan = true
        self.collectionView.addGestureRecognizer(longPressGR)
        
    }
    
                    
    
  
    @IBAction func btnSegmentTapped(_ sender: Any) {
        
      if (btnSegment.selectedSegmentIndex == 0)
      {
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
            rowWidth = rowWidth/2
            collectionView.reloadData()
        }
       
        }
        
      else {
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .vertical
            rowWidth = collectionView.frame.size.width
            collectionView.reloadData()
        }
        }
    }
    
    
    


}

//extension SecondViewController:UICollectionViewDelegateFlowLayout{
//
////    private func collectionView(collectionView: UICollectionView,
////                                layout collectionViewLayout: UICollectionViewLayout,
////                                sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
////        return CGSize(width: 100, height: 100)
////    }
////
////    func collectionView(_ collectionView: UICollectionView,
////                        layout collectionViewLayout: UICollectionViewLayout,
////                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
////        return 1.0
////    }
////
////    func collectionView(_ collectionView: UICollectionView, layout
////        collectionViewLayout: UICollectionViewLayout,
////                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
////        return 1.0
////    }
//
//
//
//}
